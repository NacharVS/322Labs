﻿using MongoDB.Bson;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IntAgiStr
{
    public partial class Form1 : Form
    {
        
        public Form1()
        {
            InitializeComponent();
           
        }
        private static async Task DBconnection(BsonDocument elementsdocs)
        {
            string connection = "mongodb://localhost";
            var person = new MongoClient(connection);
            var database = person.GetDatabase("PersonaJ");
            var collection = database.GetCollection<BsonDocument>("PersonaJ");
            await collection.InsertOneAsync(elementsdocs);
        }
        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            trackBar1.Maximum = 100;
            int str;
            str = trackBar1.Value;
            label1.Text = str.ToString();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {
            label1.Text = "0";
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void trackBar2_Scroll(object sender, EventArgs e)
        {
            trackBar2.Maximum = 100;
            int agi;
            agi = trackBar2.Value;
            label5.Text = agi.ToString();
        }

        private void trackBar3_Scroll(object sender, EventArgs e)
        {
            trackBar3.Maximum = 100;
            int intl;
            intl = trackBar3.Value;
            label6.Text = intl.ToString();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private async void button1_Click(object sender, EventArgs e)
        {
            Object id = new Object();
            PersonaJ Pers = new PersonaJ();
            Pers.Strenght = label1.Text;
            Pers.Agility = label5.Text;
            Pers.Intellect = label6.Text;
            Pers.Name = textBox1.Text;
            Pers.Password = textBox2.Text;
            BsonDocument elementsperson = Pers.ToBsonDocument();
            await DBconnection(elementsperson);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Prosm a = new Prosm();
            a.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        
    }
}
